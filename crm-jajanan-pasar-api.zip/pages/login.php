<div class="valign-wrapper" style="width:100%;position: absolute;">
    <div class="valign" style="width:100%;">
        <div class="container">
            <div class="row">
                <div class="col s12 m8 l6 offset-m2 offset-l3">
                <div class="card">
                    <div class="card-title">
                        <h5 class="center">
                            <br />
                            <span>Login Portal Adminr</span>
                        </h5>
                    </div>
                    <form action="../handler/login_action.php" method="post">
                        <div class="card-content">
                            <div class="row">
                                <div class="col s12"> 
                                    <div class="input-field">
                                        <input id="username" type="text" class="validate" placeholder="username" name="username">
                                    </div>
                                    <div class="input-field">
                                        <input id="password" type="password" class="validate" placeholder="password" name="password">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="center card-action">
                            <button class="waves-effect waves-light btn-large btn red darken-1 white-text" style="text-transform:none;width: 100%;" type="submit">
                                <b>
                                    <span>Login</span>
                                </b>    
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>