<?php

// class result query
// ini adalah class yg nantinya akan dijadikan
// object sebagai hasil dari fungsi saat query
class result_query {

    // variabel data
    public $data;

    // variabel error
    public $error;

    // konstruksi
    // fungsi yg akan dipanggil saat
    // membuat object
    public function __construct(){

    }
}

?>